import React from 'react';
import { Languages } from 'lucide-react';
import { Link } from 'react-router-dom';

interface LogoProps {
  className?: string;
  showText?: boolean;
}

const Logo = ({ className = '', showText = true }: LogoProps) => {
  return (
    <Link to="/" className={`flex items-center ${className}`}>
      <div className="relative">
        <Languages className="h-8 w-8 text-red-600" />
        <div className="absolute -top-1 -right-1 w-4 h-4 bg-white rounded-full flex items-center justify-center">
          <span className="text-xs font-bold text-red-600">&gt;</span>
        </div>
      </div>
      {showText && (
        <span className="ml-2 font-bold text-xl">DevLingua</span>
      )}
    </Link>
  );
};

export default Logo;