import React from 'react';
import { Helmet } from 'react-helmet-async';
import { Server, Cloud, GitBranch, Terminal, Code, BookOpen, Users } from 'lucide-react';

const DevOps = () => {
  return (
    <>
      <Helmet>
        <title>DevOps Services - GermanPro</title>
        <meta name="description" content="Professional DevOps consulting and training services. Learn about cloud infrastructure, CI/CD, and automation best practices." />
      </Helmet>

      <div className="bg-black text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-4xl font-bold mb-6">DevOps Services</h1>
          <p className="text-xl text-gray-300 max-w-3xl">
            Expert DevOps consulting and training to help your team implement modern development practices.
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 mb-16">
          <div>
            <h2 className="text-3xl font-bold mb-6">Our Expertise</h2>
            <p className="text-gray-600 mb-8">
              With years of experience in both software development and operations, we help teams implement efficient DevOps practices that improve productivity and reliability.
            </p>
            <div className="space-y-4">
              <div className="flex items-center">
                <Server className="h-6 w-6 text-red-600 mr-3" />
                <span className="text-gray-800">Infrastructure as Code</span>
              </div>
              <div className="flex items-center">
                <Cloud className="h-6 w-6 text-red-600 mr-3" />
                <span className="text-gray-800">Cloud Architecture</span>
              </div>
              <div className="flex items-center">
                <GitBranch className="h-6 w-6 text-red-600 mr-3" />
                <span className="text-gray-800">CI/CD Implementation</span>
              </div>
              <div className="flex items-center">
                <Terminal className="h-6 w-6 text-red-600 mr-3" />
                <span className="text-gray-800">Automation & Scripting</span>
              </div>
            </div>
          </div>
          <div className="bg-gray-50 p-8 rounded-lg">
            <h3 className="text-2xl font-bold mb-6">Featured Services</h3>
            <div className="space-y-6">
              <div>
                <h4 className="font-semibold mb-2">Infrastructure Optimization</h4>
                <p className="text-gray-600">
                  Audit and optimize your cloud infrastructure for better performance and cost efficiency.
                </p>
              </div>
              <div>
                <h4 className="font-semibold mb-2">DevOps Training</h4>
                <p className="text-gray-600">
                  Comprehensive training programs for teams transitioning to DevOps practices.
                </p>
              </div>
              <div>
                <h4 className="font-semibold mb-2">Automation Consulting</h4>
                <p className="text-gray-600">
                  Implement automation solutions for your development and deployment workflows.
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-black text-white rounded-lg p-8 mb-16">
          <h2 className="text-2xl font-bold mb-6">Why Choose Our DevOps Services?</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <Code className="h-10 w-10 text-red-600 mb-4" />
              <h3 className="text-xl font-semibold mb-3">Technical Excellence</h3>
              <p className="text-gray-300">
                Deep expertise in modern DevOps tools and practices, ensuring high-quality implementations.
              </p>
            </div>
            <div>
              <BookOpen className="h-10 w-10 text-red-600 mb-4" />
              <h3 className="text-xl font-semibold mb-3">Comprehensive Training</h3>
              <p className="text-gray-300">
                Detailed documentation and hands-on training to ensure your team's success.
              </p>
            </div>
            <div>
              <Users className="h-10 w-10 text-red-600 mb-4" />
              <h3 className="text-xl font-semibold mb-3">Collaborative Approach</h3>
              <p className="text-gray-300">
                We work closely with your team to implement solutions that fit your needs.
              </p>
            </div>
          </div>
        </div>

        <div>
          <h2 className="text-3xl font-bold mb-8">Our Process</h2>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="p-6 border border-gray-200 rounded-lg">
              <div className="text-2xl font-bold text-red-600 mb-4">01</div>
              <h3 className="text-xl font-semibold mb-3">Assessment</h3>
              <p className="text-gray-600">
                Evaluate your current infrastructure and processes to identify improvement opportunities.
              </p>
            </div>
            <div className="p-6 border border-gray-200 rounded-lg">
              <div className="text-2xl font-bold text-red-600 mb-4">02</div>
              <h3 className="text-xl font-semibold mb-3">Planning</h3>
              <p className="text-gray-600">
                Develop a detailed implementation strategy tailored to your needs.
              </p>
            </div>
            <div className="p-6 border border-gray-200 rounded-lg">
              <div className="text-2xl font-bold text-red-600 mb-4">03</div>
              <h3 className="text-xl font-semibold mb-3">Implementation</h3>
              <p className="text-gray-600">
                Execute the plan with careful attention to best practices and security.
              </p>
            </div>
            <div className="p-6 border border-gray-200 rounded-lg">
              <div className="text-2xl font-bold text-red-600 mb-4">04</div>
              <h3 className="text-xl font-semibold mb-3">Training</h3>
              <p className="text-gray-600">
                Ensure your team is equipped with the knowledge to maintain and improve the system.
              </p>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default DevOps;