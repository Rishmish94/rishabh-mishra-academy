import React from 'react';
import { Helmet } from 'react-helmet-async';
import { BookOpen, Terminal } from 'lucide-react';
import { Link } from 'react-router-dom';

const Blog = () => {
  const posts = [
    {
      id: 1,
      title: "Mastering German Articles: A Comprehensive Guide",
      excerpt: "Understanding when to use der, die, and das is crucial for German language learners...",
      category: "Language Learning",
      date: "2024-02-15",
      icon: BookOpen
    },
    {
      id: 2,
      title: "DevOps Best Practices for Startups",
      excerpt: "Essential DevOps practices that every startup should implement for better efficiency...",
      category: "DevOps",
      date: "2024-02-10",
      icon: Terminal
    },
    // Add more blog posts here
  ];

  return (
    <>
      <Helmet>
        <title>Blog - GermanPro</title>
        <meta name="description" content="Read our latest articles about German language learning, culture, and DevOps best practices." />
      </Helmet>

      <div className="bg-black text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-4xl font-bold mb-6">Blog</h1>
          <p className="text-xl text-gray-300 max-w-3xl">
            Insights on German language learning, culture, and DevOps practices.
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {posts.map(post => {
            const Icon = post.icon;
            return (
              <article key={post.id} className="border border-gray-200 rounded-lg p-6 hover:shadow-lg transition-shadow">
                <div className="flex items-center mb-4">
                  <Icon className="h-6 w-6 text-red-600 mr-2" />
                  <span className="text-sm text-gray-500">{post.category}</span>
                </div>
                <h2 className="text-2xl font-bold mb-3">{post.title}</h2>
                <p className="text-gray-600 mb-4">{post.excerpt}</p>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-500">{post.date}</span>
                  <Link to={`/blog/${post.id}`} className="text-red-600 hover:text-red-700 font-medium">
                    Read more →
                  </Link>
                </div>
              </article>
            );
          })}
        </div>
      </div>
    </>
  );
};

export default Blog;