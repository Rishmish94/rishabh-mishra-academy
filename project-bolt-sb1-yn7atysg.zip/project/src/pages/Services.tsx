import React from 'react';
import { Helmet } from 'react-helmet-async';
import { BookOpen, Users, Briefcase, Video, Terminal } from 'lucide-react';

const Services = () => {
  return (
    <>
      <Helmet>
        <title>Services - GermanPro</title>
        <meta name="description" content="Professional German language instruction services including one-on-one coaching, group classes, and business German courses." />
      </Helmet>

      <div className="bg-black text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-4xl font-bold mb-6">Our Services</h1>
          <p className="text-xl text-gray-300 max-w-3xl">
            Comprehensive German language instruction tailored to your needs.
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="bg-white p-8 rounded-lg border border-gray-200">
            <BookOpen className="h-12 w-12 text-red-600 mb-4" />
            <h2 className="text-2xl font-bold mb-4">One-on-One Coaching</h2>
            <p className="text-gray-600 mb-6">
              Personalized German language instruction tailored to your learning style and goals.
            </p>
            <ul className="space-y-3 text-gray-600 mb-8">
              <li className="flex items-center">
                <span className="h-2 w-2 bg-red-600 rounded-full mr-2"></span>
                Flexible scheduling
              </li>
              <li className="flex items-center">
                <span className="h-2 w-2 bg-red-600 rounded-full mr-2"></span>
                Customized curriculum
              </li>
              <li className="flex items-center">
                <span className="h-2 w-2 bg-red-600 rounded-full mr-2"></span>
                Progress tracking
              </li>
            </ul>
            <button className="w-full bg-red-600 text-white py-3 rounded-md hover:bg-red-700">
              Book a Session
            </button>
          </div>

          <div className="bg-white p-8 rounded-lg border border-gray-200">
            <Briefcase className="h-12 w-12 text-red-600 mb-4" />
            <h2 className="text-2xl font-bold mb-4">Business German</h2>
            <p className="text-gray-600 mb-6">
              Specialized instruction for professionals working with German companies.
            </p>
            <ul className="space-y-3 text-gray-600 mb-8">
              <li className="flex items-center">
                <span className="h-2 w-2 bg-red-600 rounded-full mr-2"></span>
                Business vocabulary
              </li>
              <li className="flex items-center">
                <span className="h-2 w-2 bg-red-600 rounded-full mr-2"></span>
                Email writing
              </li>
              <li className="flex items-center">
                <span className="h-2 w-2 bg-red-600 rounded-full mr-2"></span>
                Meeting preparation
              </li>
            </ul>
            <button className="w-full bg-red-600 text-white py-3 rounded-md hover:bg-red-700">
              Learn More
            </button>
          </div>
        </div>

        <div className="mt-16">
          <h2 className="text-3xl font-bold mb-8">Additional Offerings</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="p-6 border border-gray-200 rounded-lg">
              <Users className="h-10 w-10 text-red-600 mb-4" />
              <h3 className="text-xl font-semibold mb-2">Group Classes</h3>
              <p className="text-gray-600">Small group sessions for interactive learning and practice.</p>
            </div>
            <div className="p-6 border border-gray-200 rounded-lg">
              <Video className="h-10 w-10 text-red-600 mb-4" />
              <h3 className="text-xl font-semibold mb-2">Online Courses</h3>
              <p className="text-gray-600">Self-paced video courses for flexible learning.</p>
            </div>
            <div className="p-6 border border-gray-200 rounded-lg">
              <Terminal className="h-10 w-10 text-red-600 mb-4" />
              <h3 className="text-xl font-semibold mb-2">Technical German</h3>
              <p className="text-gray-600">Specialized vocabulary for IT and DevOps professionals.</p>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Services;