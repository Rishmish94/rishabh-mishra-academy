import React from 'react';
import { Helmet } from 'react-helmet-async';
import { ArrowRight, BookOpen, Globe, MessageSquare } from 'lucide-react';
import { Link } from 'react-router-dom';

const Home = () => {
  return (
    <>
      <Helmet>
        <title>GermanPro - Professional German Language Instruction</title>
        <meta name="description" content="Master German with personalized one-on-one classes. Professional language instruction tailored to your needs." />
      </Helmet>

      {/* Hero Section */}
      <section className="relative bg-black text-white">
        <div className="absolute inset-0">
          <img
            src="https://images.unsplash.com/photo-1527866959252-deab85ef7d1b?auto=format&fit=crop&q=80"
            alt="Berlin cityscape"
            className="w-full h-full object-cover opacity-20"
          />
        </div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
          <div className="max-w-3xl">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">Master German with Professional One-on-One Instruction</h1>
            <p className="text-xl mb-8">Personalized language coaching tailored to your goals and learning style.</p>
            <div className="flex space-x-4">
              <Link to="/services" className="bg-red-600 text-white px-8 py-3 rounded-md font-medium hover:bg-red-700 flex items-center">
                Start Learning <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
              <Link to="/contact" className="bg-white text-black px-8 py-3 rounded-md font-medium hover:bg-gray-100">
                Contact Us
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="p-6 border border-gray-200 rounded-lg">
              <BookOpen className="h-10 w-10 text-red-600 mb-4" />
              <h3 className="text-xl font-semibold mb-2">Personalized Learning</h3>
              <p className="text-gray-600">Customized curriculum based on your goals and current proficiency level.</p>
            </div>
            <div className="p-6 border border-gray-200 rounded-lg">
              <Globe className="h-10 w-10 text-red-600 mb-4" />
              <h3 className="text-xl font-semibold mb-2">Cultural Immersion</h3>
              <p className="text-gray-600">Learn about German culture, customs, and business etiquette.</p>
            </div>
            <div className="p-6 border border-gray-200 rounded-lg">
              <MessageSquare className="h-10 w-10 text-red-600 mb-4" />
              <h3 className="text-xl font-semibold mb-2">Interactive Sessions</h3>
              <p className="text-gray-600">Engaging conversations and practical exercises for rapid improvement.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Newsletter Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-2xl mx-auto text-center">
            <h2 className="text-3xl font-bold mb-4">Subscribe to Our Newsletter</h2>
            <p className="text-gray-600 mb-6">Get weekly German learning tips and cultural insights delivered to your inbox.</p>
            <form className="flex gap-2">
              <input
                type="email"
                placeholder="Enter your email"
                className="flex-1 px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-red-600"
              />
              <button type="submit" className="bg-red-600 text-white px-6 py-2 rounded-md hover:bg-red-700">
                Subscribe
              </button>
            </form>
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;