import React from 'react';
import { Helmet } from 'react-helmet-async';
import { GraduationCap, Globe, Code } from 'lucide-react';

const About = () => {
  return (
    <>
      <Helmet>
        <title>About - GermanPro</title>
        <meta name="description" content="Learn about our professional German language instruction and DevOps expertise. Discover our teaching methodology and experience." />
      </Helmet>

      <div className="bg-black text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-4xl font-bold mb-6">About GermanPro</h1>
          <p className="text-xl text-gray-300 max-w-3xl">
            Bridging the gap between language learning and technical expertise, providing professional German instruction and DevOps knowledge.
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
          <div>
            <GraduationCap className="h-12 w-12 text-red-600 mb-4" />
            <h2 className="text-2xl font-bold mb-4">Educational Background</h2>
            <p className="text-gray-600">
              Certified language instructor with over a decade of experience teaching German at all levels, from beginners to advanced business German.
            </p>
          </div>
          <div>
            <Globe className="h-12 w-12 text-red-600 mb-4" />
            <h2 className="text-2xl font-bold mb-4">Cultural Expertise</h2>
            <p className="text-gray-600">
              Native German speaker with deep understanding of both traditional and modern German culture, business practices, and social norms.
            </p>
          </div>
          <div>
            <Code className="h-12 w-12 text-red-600 mb-4" />
            <h2 className="text-2xl font-bold mb-4">Technical Knowledge</h2>
            <p className="text-gray-600">
              Experienced DevOps engineer bringing a unique blend of technical expertise and language instruction capabilities.
            </p>
          </div>
        </div>

        <div className="mt-16">
          <h2 className="text-3xl font-bold mb-8">Our Teaching Methodology</h2>
          <div className="bg-gray-50 p-8 rounded-lg">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div>
                <h3 className="text-xl font-semibold mb-4">Personalized Approach</h3>
                <p className="text-gray-600 mb-4">
                  Every student's learning journey is unique. We tailor our teaching methods to match your goals, learning style, and pace.
                </p>
                <ul className="list-disc list-inside text-gray-600 space-y-2">
                  <li>Customized lesson plans</li>
                  <li>Regular progress assessments</li>
                  <li>Flexible scheduling</li>
                  <li>One-on-one attention</li>
                </ul>
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-4">Immersive Learning</h3>
                <p className="text-gray-600 mb-4">
                  Our immersive approach combines language instruction with cultural context and real-world applications.
                </p>
                <ul className="list-disc list-inside text-gray-600 space-y-2">
                  <li>Cultural integration</li>
                  <li>Real-world conversations</li>
                  <li>Business German focus</li>
                  <li>Technical vocabulary</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default About;